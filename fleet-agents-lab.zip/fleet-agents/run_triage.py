import sys
from agent import load_agent

agent = load_agent("fleet_agent.json")
task = " ".join(sys.argv[1:]) or "Truck 102 won't start this morning."
result = agent.run(task)
for name, args, res in result["trace"]:
    print(f"  {name}({args}) -> {res}")
print(result["answer"], f"[{result['steps']} steps]")
