from agent import load_agent
from evals import run_suite

CANDIDATES = [
    {"provider": "mock", "id": "mock-1"},
    {"provider": "mock", "id": "mock-misbehave", "misbehave": True},
    # {"provider": "openai_compat", "id": "your-small-model"},   # add real models here
]
print(f"{'model':<18}{'pass':>6}{'steps':>7}{'sec':>7}")
for spec in CANDIDATES:
    r = run_suite(load_agent("fleet_agent.json", spec), verbose=False)
    print(f"{r['model']:<18}{r['pass_rate']:>6.0%}{r['avg_steps']:>7}{r['seconds']:>7}")
