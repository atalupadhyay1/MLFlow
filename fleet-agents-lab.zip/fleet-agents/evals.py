import json, sys, time
import tools
from agent import load_agent

CASES = [  # (task, expected priority or None if the agent should escalate)
    ("Truck 101 won't start.", "urgent"),
    ("Truck 102 has a coolant leak.", "high"),
    ("Truck 101 is due for its scheduled oil change.", "low"),
    ("Truck 102 radio is crackly.", "normal"),
    ("Truck 101 is making a grinding sound when braking.", "urgent"),
    ("Truck 999 won't start.", None),
]


def final_priority(trace):
    for name, args, res in reversed(trace):
        if name == "set_priority" and "error" not in res:
            return res["priority"]


def run_suite(agent, verbose=True):
    passed, steps, start = 0, 0, time.time()
    for task, expected in CASES:
        tools.SCHEDULE.clear()
        r = agent.run(task)
        got = final_priority(r["trace"])
        ok = got == expected and (expected is None or len(tools.SCHEDULE) == 1)
        passed += ok
        steps += r["steps"]
        if verbose:
            print(("PASS" if ok else "FAIL"), "|", task, "| expected", expected, "got", got)
    n = len(CASES)
    return {"model": agent.model.name, "pass_rate": passed / n,
            "avg_steps": round(steps / n, 1), "seconds": round(time.time() - start, 2)}


if __name__ == "__main__":
    print(run_suite(load_agent("fleet_agent.json")))
