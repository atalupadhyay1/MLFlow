from agent import load_agent

# 1. A model that first tries an invalid priority, to test the hook
agent = load_agent("fleet_agent.json", {"provider": "mock", "misbehave": True})
result = agent.run("Truck 101 has a coolant leak.")
for step in result["trace"]:
    print(step)
print(result["answer"], result["steps"], "steps\n")

# 2. Ask for a tool the agent was never given
print(agent._execute("post_to_social", {"text": "hello"}), "\n")

# 3. Cap the run too low and watch it stop safely
agent.max_steps = 2
print(agent.run("Truck 101 won't start.")["answer"])
