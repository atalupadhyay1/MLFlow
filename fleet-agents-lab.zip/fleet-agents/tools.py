"""Everything an agent could do (TOOLS) and the checks that always run (HOOKS)."""
TOOLS = {}
SCHEDULE = []
FLEET = {
    "101": {"model": "Ford Transit", "status": "in_service"},
    "102": {"model": "Ram ProMaster", "status": "in_service"},
    "103": {"model": "Ford Transit", "status": "down"},
}
STOCK = {"A-17": 4, "B-02": 0}
PRIORITIES = {"low", "normal", "high", "urgent"}


def tool(description, properties, required):
    def wrap(fn):
        TOOLS[fn.__name__] = {"fn": fn, "schema": {"type": "function", "function": {
            "name": fn.__name__, "description": description,
            "parameters": {"type": "object", "properties": properties, "required": required}}}}
        return fn
    return wrap


S = {"type": "string"}


@tool("Look up a truck by id.", {"truck_id": S}, ["truck_id"])
def lookup_truck(truck_id):
    t = FLEET.get(str(truck_id))
    return {"truck_id": str(truck_id), **t} if t else {"error": f"no truck {truck_id}"}


@tool("Set the repair priority: low, normal, high or urgent.",
      {"truck_id": S, "priority": S}, ["truck_id", "priority"])
def set_priority(truck_id, priority):
    return {"truck_id": truck_id, "priority": priority}


@tool("Book a repair slot.", {"truck_id": S, "priority": S, "when": S},
      ["truck_id", "priority", "when"])
def schedule_repair(truck_id, priority, when):
    SCHEDULE.append({"truck_id": truck_id, "priority": priority, "when": when})
    return {"scheduled": True, "when": when}


@tool("Check how many of a part are in stock.", {"part": S}, ["part"])
def check_stock(part):
    return {"part": part, "on_hand": STOCK.get(part, 0)}


@tool("Post a message to social media.", {"text": S}, ["text"])
def post_to_social(text):  # exists in the building, but no agent is given it
    return {"posted": True}


def valid_priority(name, args):
    if name in ("set_priority", "schedule_repair") and args.get("priority") not in PRIORITIES:
        return f"priority must be one of {sorted(PRIORITIES)}"


def known_truck(name, args):
    if "truck_id" in args and str(args["truck_id"]) not in FLEET:
        return f"truck {args['truck_id']} is not in the fleet"


HOOKS = {"valid_priority": valid_priority, "known_truck": known_truck}
