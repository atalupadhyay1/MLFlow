"""Models behind one tiny interface: chat(messages, tools) -> assistant message dict."""
import itertools
import json
import os
import re

_ids = itertools.count(1)


def _call(name, args):
    return {"role": "assistant", "content": "", "tool_calls": [
        {"id": f"call_{next(_ids)}", "type": "function",
         "function": {"name": name, "arguments": json.dumps(args)}}]}


def classify(text):
    t = text.lower()
    if any(w in t for w in ["won't start", "no cooling", "brake", "smoke", "overheat"]):
        return "urgent"
    if any(w in t for w in ["noise", "leak", "warning light"]):
        return "high"
    if any(w in t for w in ["oil change", "scheduled", "inspection"]):
        return "low"
    return "normal"


class MockModel:
    """A scripted stand-in so every lab runs offline, free and deterministic."""

    def __init__(self, misbehave=False):
        self.misbehave = misbehave
        self.name = "mock-misbehave" if misbehave else "mock-1"

    def chat(self, messages, tools):
        offered = {t["function"]["name"] for t in tools}
        user = next(m["content"] for m in messages if m["role"] == "user")
        results = {}  # tool name -> list of parsed results, in order
        for m in messages:
            if m["role"] == "tool":
                results.setdefault(m["name"], []).append(json.loads(m["content"]))

        if "check_stock" in offered:
            part = (re.search(r"part\s+([A-Za-z0-9-]+)", user, re.I) or [None, "?"])[1]
            if "check_stock" not in results:
                return _call("check_stock", {"part": part})
            r = results["check_stock"][-1]
            return {"role": "assistant", "content": f"Part {part}: {r.get('on_hand', 0)} in stock."}

        truck = (re.search(r"truck\s*#?(\d+)", user, re.I) or [None, "0"])[1]
        if "lookup_truck" not in results:
            return _call("lookup_truck", {"truck_id": truck})
        if "error" in results["lookup_truck"][-1]:
            return {"role": "assistant", "content": f"Truck {truck} not found. Escalating to a human."}
        prio = classify(user)
        tries = results.get("set_priority", [])
        if not tries or ("error" in tries[-1] and len(tries) < 3):
            bad = self.misbehave and not tries
            return _call("set_priority", {"truck_id": truck, "priority": "ASAP!!" if bad else prio})
        if "error" in tries[-1]:
            return {"role": "assistant", "content": "Could not set a valid priority. Escalating."}
        if "schedule_repair" not in results:
            when = "today" if prio == "urgent" else "this week"
            return _call("schedule_repair", {"truck_id": truck, "priority": prio, "when": when})
        return {"role": "assistant", "content": f"Truck {truck}: priority {prio}, repair scheduled."}


class OpenAICompatModel:
    """Any OpenAI-compatible endpoint: pip install openai. Set LLM_BASE_URL and LLM_API_KEY."""

    def __init__(self, model_id, base_url_env="LLM_BASE_URL", api_key_env="LLM_API_KEY"):
        from openai import OpenAI
        self.name = model_id
        self.client = OpenAI(base_url=os.getenv(base_url_env), api_key=os.environ[api_key_env])

    def chat(self, messages, tools):
        r = self.client.chat.completions.create(
            model=self.name, messages=messages, tools=tools, temperature=0)
        msg = r.choices[0].message
        out = {"role": "assistant", "content": msg.content or ""}
        if msg.tool_calls:
            out["tool_calls"] = [
                {"id": t.id, "type": "function",
                 "function": {"name": t.function.name, "arguments": t.function.arguments}}
                for t in msg.tool_calls]
        return out


def build_model(spec):
    if spec["provider"] == "mock":
        return MockModel(misbehave=spec.get("misbehave", False))
    return OpenAICompatModel(spec["id"], spec.get("base_url_env", "LLM_BASE_URL"),
                             spec.get("api_key_env", "LLM_API_KEY"))
