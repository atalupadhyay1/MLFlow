from agent import load_agent

FLEET = {  # standard interface: every agent has run(task) -> dict
    "fleet": load_agent("fleet_agent.json"),
    "parts": load_agent("parts_agent.json"),
}
ROUTES = {"truck": "fleet", "part": "parts"}   # deterministic router: cheap, testable


def handle(task):
    picked = [agent for word, agent in ROUTES.items() if word in task.lower()]
    if not picked:
        return "No agent for this. Escalating to a human."
    return "\n".join(f"[{a}] {FLEET[a].run(task)['answer']}" for a in dict.fromkeys(picked))


if __name__ == "__main__":
    for t in ["Truck 102 won't start. Do we have part A-17?", "Order lunch for the crew."]:
        print(t, "\n", handle(t), "\n")
