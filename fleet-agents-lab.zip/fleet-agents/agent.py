import json
from llm import build_model
from tools import HOOKS, TOOLS


class Agent:
    def __init__(self, name, model, system_prompt, tool_names, hooks=(), max_steps=6):
        self.name, self.model, self.system_prompt, self.max_steps = name, model, system_prompt, max_steps
        self.tools = {n: TOOLS[n] for n in tool_names}          # least privilege
        self.schemas = [t["schema"] for t in self.tools.values()]
        self.hooks = [HOOKS[h] for h in hooks]

    def _execute(self, name, args):
        if name not in self.tools:
            return {"error": f"tool '{name}' is not available to this agent"}
        for hook in self.hooks:
            problem = hook(name, args)
            if problem:
                return {"error": f"blocked by hook: {problem}"}
        try:
            return self.tools[name]["fn"](**args)
        except Exception as e:
            return {"error": f"{type(e).__name__}: {e}"}

    def run(self, task):
        messages = [{"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": task}]
        trace = []
        for step in range(1, self.max_steps + 1):
            reply = self.model.chat(messages, self.schemas)
            messages.append(reply)
            calls = reply.get("tool_calls") or []
            if not calls:
                return {"ok": True, "answer": reply["content"], "steps": step, "trace": trace}
            for c in calls:
                name = c["function"]["name"]
                try:
                    args = json.loads(c["function"]["arguments"] or "{}")
                    result = self._execute(name, args)
                except json.JSONDecodeError:
                    args, result = {}, {"error": "arguments were not valid JSON"}
                trace.append((name, args, result))
                messages.append({"role": "tool", "tool_call_id": c["id"], "name": name,
                                 "content": json.dumps(result)})
        return {"ok": False, "answer": "Step limit reached. Escalate to a human.",
                "steps": self.max_steps, "trace": trace}


def load_agent(path, model_spec=None):
    """Build an agent from a manifest. The manifest pins the model unless you override it."""
    m = json.load(open(path))
    spec = model_spec or m["model"]
    return Agent(m["name"], build_model(spec), m["system_prompt"], m["tools"],
                 m.get("hooks", []), m.get("max_steps", 6))
